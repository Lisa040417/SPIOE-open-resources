%%
%3.4
fs=100;
N=1024;
t=(0:N-1)/fs;
x=3*cos(8*pi*t)+0.003*cos(12*pi*t);
f=(0:N-1)*(fs/N);
% No window FFT
X_no_window=fft(x);
X_magnitude_no_window=abs(X_no_window);
% 汉宁窗
hanning_window=hanning(N)';
x_hanning=x.*hanning_window;
X_hanning=fft(x_hanning);
X_magnitude_hanning = abs(X_hanning);
% 海明窗
hamming_window=hamming(N)';
x_hamming=x.*hamming_window;
X_hamming=fft(x_hamming);
X_magnitude_hamming=abs(X_hamming);
% 布莱克曼窗
blackman_window=blackman(N)';
x_blackman=x.*blackman_window;
X_blackman=fft(x_blackman);
X_magnitude_blackman=abs(X_blackman);
figure;
% No window
subplot(4, 1, 1);
stem(f, 20*log10(X_magnitude_no_window));
title('不加窗');
xlabel('频率');
ylabel('分贝');
grid on;
% 汉宁窗
subplot(4, 1, 2);
stem(f, 20*log10(X_magnitude_hanning));
title('汉宁窗');
xlabel('频率');
ylabel('分贝');
grid on;
% 汉明窗
subplot(4, 1, 3);
stem(f, 20*log10(X_magnitude_hamming));
title('汉明窗');
xlabel('频率');
ylabel('分贝');
grid on;
% 布莱克曼窗
subplot(4, 1, 4);
stem(f, 20*log10(X_magnitude_blackman));
title('布莱克曼窗');
xlabel('频率');
ylabel('分贝');
grid on;

%%
fs=100;
N=1024;
t=(0:N-1)/fs;
x=3*cos(8*pi*t)+0.003*cos(12*pi*t);
f=(0:N-1)*(fs/N);
% No window FFT
X_no_window=fft(x);
X_magnitude_no_window=abs(X_no_window);
% 汉宁窗
hanning_window=hanning(N)';
x_hanning=x.*hanning_window;
X_hanning=fft(x_hanning);
X_magnitude_hanning = abs(X_hanning);
% 海明窗
hamming_window=hamming(N)';
x_hamming=x.*hamming_window;
X_hamming=fft(x_hamming);
X_magnitude_hamming=abs(X_hamming);
% 布莱克曼窗
blackman_window=blackman(N)';
x_blackman=x.*blackman_window;
X_blackman=fft(x_blackman);
X_magnitude_blackman=abs(X_blackman);
figure;
% No window
subplot(4, 1, 1);
stem(f, X_magnitude_no_window);
title('不加窗');
xlabel('频率');
ylabel('分贝');
grid on;
% 汉宁窗
subplot(4, 1, 2);
stem(f, X_magnitude_hanning);
title('汉宁窗');
xlabel('频率');
ylabel('分贝');
grid on;
% 汉明窗
subplot(4, 1, 3);
stem(f, X_magnitude_hamming);
title('汉明窗');
xlabel('频率');
ylabel('分贝');
grid on;
% 布莱克曼窗
subplot(4, 1, 4);
stem(f, X_magnitude_blackman);
title('布莱克曼窗');
xlabel('频率');
ylabel('分贝');
grid on;

%%
fs=100;
N=1024;
t=(0:N-1)/fs;
x=3*cos(8*pi*t)+0.003*cos(12*pi*t);
f=(0:N-1)*(fs/N);
% No window FFT
X_no_window=fft(x);
X_magnitude_no_window=abs(X_no_window);
% 汉宁窗
hanning_window=hanning(N)';
x_hanning=x.*hanning_window;
X_hanning=fft(x_hanning);
X_magnitude_hanning = abs(X_hanning);
% 海明窗
hamming_window=hamming(N)';
x_hamming=x.*hamming_window;
X_hamming=fft(x_hamming);
X_magnitude_hamming=abs(X_hamming);
% 布莱克曼窗
blackman_window=blackman(N)';
x_blackman=x.*blackman_window;
X_blackman=fft(x_blackman);
X_magnitude_blackman=abs(X_blackman);
figure;
% No window
subplot(4, 1, 1);
plot(f, 20*log10(X_magnitude_no_window));
title('不加窗');
xlabel('频率');
ylabel('分贝');
grid on;
% 汉宁窗
subplot(4, 1, 2);
plot(f, 20*log10(X_magnitude_hanning));
title('汉宁窗');
xlabel('频率');
ylabel('分贝');
grid on;
% 汉明窗
subplot(4, 1, 3);
plot(f, 20*log10(X_magnitude_hamming));
title('汉明窗');
xlabel('频率');
ylabel('分贝');
grid on;
% 布莱克曼窗
subplot(4, 1, 4);
plot(f, 20*log10(X_magnitude_blackman));
title('布莱克曼窗');
xlabel('频率');
ylabel('分贝');
grid on;

%%
fs=100;
N=128;
t=(0:N-1)/fs;
x=3*cos(8*pi*t)+0.003*cos(12*pi*t);
f=(0:N-1)*(fs/N);
% No window FFT
X_no_window=fft(x);
X_magnitude_no_window=abs(X_no_window);
% 汉宁窗
hanning_window=hanning(N)';
x_hanning=x.*hanning_window;
X_hanning=fft(x_hanning);
X_magnitude_hanning = abs(X_hanning);
% 海明窗
hamming_window=hamming(N)';
x_hamming=x.*hamming_window;
X_hamming=fft(x_hamming);
X_magnitude_hamming=abs(X_hamming);
% 布莱克曼窗
blackman_window=blackman(N)';
x_blackman=x.*blackman_window;
X_blackman=fft(x_blackman);
X_magnitude_blackman=abs(X_blackman);
figure;
% No window
subplot(4, 1, 1);
plot(f, X_magnitude_no_window);
title('不加窗');
xlabel('频率');
ylabel('分贝');
grid on;
% 汉宁窗
subplot(4, 1, 2);
plot(f, X_magnitude_hanning);
title('汉宁窗');
xlabel('频率');
ylabel('分贝');
grid on;
% 汉明窗
subplot(4, 1, 3);
plot(f, X_magnitude_hamming);
title('汉明窗');
xlabel('频率');
ylabel('分贝');
grid on;
% 布莱克曼窗
subplot(4, 1, 4);
plot(f, X_magnitude_blackman);
title('布莱克曼窗');
xlabel('频率');
ylabel('分贝');
grid on;