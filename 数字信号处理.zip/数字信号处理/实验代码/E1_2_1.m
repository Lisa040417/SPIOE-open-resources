% 3.2(1)
n=0:25;
x3=cos(pi/4*n);
x4=cos(pi/4*n)+0.5*cos(pi/8*n+pi/3);
x5=exp(1j*pi*n/4);
N_values=[8, 12, 16];
figure;
for i=1:3
    N=N_values(i);
    X3=fft(x3, N);
    magnitude_spectrum=abs(X3);
    % Axis
    k=0:N-1;
    % Plot
    subplot(3, 3, i);
    stem(k, magnitude_spectrum, 'fill');
    title(['N=' num2str(N)]);
    xlabel('频率');
    ylabel('X3幅值');
    grid on;
end
for i=1:3
    N=N_values(i);
    X4=fft(x4, N);
    magnitude_spectrum=abs(X4);
    % Axis
    k=0:N-1;
    % Plot
    subplot(3, 3, i+3);
    stem(k, magnitude_spectrum, 'fill');
    title(['N=' num2str(N)]);
    xlabel('频率');
    ylabel('X4幅值');
    grid on;
end
for i=1:3
    N=N_values(i);
    X3=fft(x5, N);
    magnitude_spectrum=abs(X3);
    % Axis
    k=0:N-1;
    % Plot
    subplot(3, 3, i+6);
    stem(k, magnitude_spectrum, 'fill');
    title(['N=' num2str(N)]);
    xlabel('频率');
    ylabel('X5幅值');
    grid on;
end