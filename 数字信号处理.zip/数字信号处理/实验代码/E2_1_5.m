% 实验2 5 1
fs = 1024;
N = 1024;
fo = 10;
fp = 40;
ap = 3;     % dB
filter_order = 5;
n = 0:N-1;
t = n / fs;

xa = sin(2*pi*fo*t);
% Noise
noise = 100 * rand(1, N);

% Butterworth filter
wp = fp / (fs / 2);
[b, a] = butter(filter_order, wp, 'high');
filtered_noise = filter(b, a, noise);

signal_with_noise = xa + filtered_noise;
% fig(time)
figure;
subplot(2, 1, 1);
plot(t, signal_with_noise);
title('Sine with Filtered Noise');
xlabel('t(s)');
ylabel('Amplitude');

% fig(freq)
xf_sine = fft(xa);
xf_noise = fft(noise);
xf_filtered_noise = fft(filtered_noise);
xf_signal_with_noise = fft(signal_with_noise);

f = n * fs / N;
subplot(2, 1, 2);
plot(f, abs(xf_signal_with_noise));
title('Frequency figure of Sine + Filtered Noise');
xlabel('Frequency(Hz)');
ylabel('Magnitude');
xlim([0, 200]);
