% 实验2 5 2
Fs = 1000;
N = 2000;
fo = 10;
fc = 100;
n = 0:N-1;
t = n / Fs;
xa = cos(2*pi*fo*t) .* cos(2*pi*fc*t);

% Generate noise
noise = randn(1, N);
% Butterworth filter
fp = 160;
fs = 130;
ap = 1;     % dB
as = 30;    % dB
wp = fp / (Fs / 2);
ws = fs / (Fs / 2);
[N_d, wc_d] = buttord(wp, ws, ap, as); 
[b_d, a_d] = butter(N_d, wc_d, 'high');

filtered_noise = filter(b_d, a_d, noise);
signal_with_noise = xa + filtered_noise;

% fig(time)
figure;
subplot(2,1,1);
plot(t, signal_with_noise);
title('Signal with High-frequency Noise');
xlabel('t(s)');
ylabel('Amplitude');

% fig(freq)
xf_signal = fft(signal_with_noise);
f = (0:N-1) * Fs / N;
subplot(2,1,2);
plot(f, abs(xf_signal));
title('Frequency figure of Signal with Noise');
xlabel('Frequency (Hz)');
ylabel('Magnitude');
xlim([0, 500]);
