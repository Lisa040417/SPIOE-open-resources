%3.3
% Do 256-point FFT
fs=6.4;
N=256;
t=0:1/fs:1-1/fs;
signal=@(t) cos(pi*t/8)+2*cos(3*pi*t/4);
t_sampled=0:1/fs:(N-1)/fs;
x=signal(t_sampled);
Y=fft(x, N); 
f=fs*(0:(N-1))/N;
figure;
subplot(3,1,1);
stem(f, abs(Y), 'fill');
title(['N=' num2str(N)]);
xlabel('频率');
ylabel('幅值');
grid on;
% Fill 256 0 in x_sample, then do 512-point FFT
z=zeros(256);
x1=[x, z(256,:)];
Y1=fft(x1, 512); 
f1=fs*(0:511)/512;
subplot(3,1,2);
stem(f1, abs(Y1), 'fill');
title(['N=' 512]);
xlabel('频率');
ylabel('幅值');
grid on;
% Do 512-point FFT
t_sampled1=0:1/fs:511/fs;
x2=signal(t_sampled1);
Y2=fft(x2, 512); 
f2=fs*(0:511)/512;
subplot(3,1,3);
stem(f2, abs(Y2), 'fill');
title(['N=' 512]);
xlabel('频率');
ylabel('幅值');
grid on;