%ʵ��2  1����3·���������ź�
clear all;
N=1600;
fs=10000;
Ts=1/fs;
n=0:1:(N-1);
t=n*Ts;
fc1=1000; fo1=100;
fc2=500;  fo2=50;
fc3=250;  fo3=25;
x=cos(2*pi*fo1*t).*cos(2*pi*fc1*t)+cos(2*pi*fo2*t).*cos(2*pi*fc2*t)+cos(2*pi*fo3*t).*cos(2*pi*fc3*t);
subplot(3,1,1);
plot(t,x);
xlabel('t(s)')
title('ʱ��ͼ��');
subplot(3,1,2);
xf=fft(x);
plot(n,abs(xf));
title('Ƶ��ͼ');
xlabel('k');
subplot(3,1,3);
n1=0:1:N/2-1;
% x1=xf(1:N/2);
xfhalf=2*abs(xf(1:N/2))/N;
xfhalf(1)=abs(xf(1))/N;
plot(n1*fs/N,xfhalf);
title('Ƶ��ͼ');
xlabel('f(Hz)');

