#pragma once
#include "part2.h"

void opencvTest(vector<Point2d> pts1, vector<Point2d> pts2);