#pragma once

#include "part2.h"

void calLength(vector<MatrixXd> RT, vector<Vector2d> pointImg0, vector<Vector2d> pointImg1);