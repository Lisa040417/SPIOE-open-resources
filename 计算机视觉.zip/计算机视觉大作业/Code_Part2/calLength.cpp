#include "calLength.h"

void calLength(vector<MatrixXd> RT, vector<Vector2d> pointImg0, vector<Vector2d> pointImg1) {
	Vector2d p[4], q[4];			// Image 0 and Image 1
	double d1, d2;					// Return value
	Matrix3d R;
	Vector3d t;
	Matrix<double, 3, 4> P1, P2;
	Matrix3d K_m;
	Vector4d P[4];
	double scale, length;

	R = RT[0].leftCols(3);
	t = RT[0].rightCols(1);
	K_m << 4705.5337, 0, 3944.07, 0, 4705.5337, 2612.675, 0, 0, 1;

	P1 << K_m * Matrix3d::Identity(), Vector3d::Zero();
	P2 << K_m * R, K_m* t;

	for (int i = 0; i < 4; i++) {
		p[i] = pointImg0[i];
		q[i] = pointImg1[i];
		P[i] = triangulatePoint(P1, P2, p[i], q[i]);
	}

	// Cal length 
	d1 = (P[0].head<3>() - P[1].head<3>()).norm();
	d2 = (P[2].head<3>() - P[3].head<3>()).norm();
	scale = 1000.0 / d1;
	length = d2 * scale;
	std::cout << "Length of the 2nd ruler: " << length << " mm" << std::endl;

}