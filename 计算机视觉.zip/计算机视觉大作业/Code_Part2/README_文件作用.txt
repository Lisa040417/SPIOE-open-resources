main.cpp: 主函数;
part2.cpp: 自行编写的part2（1）的算法;
part2_opencv.cpp: 使用opencv与自编写函数做验证;
calLength.cpp: 长度计算

part2.h, part2_opencv.h, calLength.h是相应的头文件。