#include "part2.h"
#include "part2_opencv.h"
#include "calLength.h"

// 8 points for calculating matrix F
// Point 1: 2606; Point 2: 3308; Point 3: 3401; Point 4: 2903;  
// Point 5: 1; Point 6: 2; Point 7: 3; Point 8: 4;
const Point2d fig0_1(3522.5512, 942.5185);
const Point2d fig1_1(5907.4902, 2557.3595);
const Point2d fig0_2(4295.4749, 2698.9412);
const Point2d fig1_2(3380.9717, 2697.2484);
const Point2d fig0_3(3043.512, 3559.9259);
const Point2d fig1_3(2896.8671, 1516.4858);
const Point2d fig0_4(5616.793, 2486.5359);
const Point2d fig1_4(3227.4749, 4288.1481);
const Point2d fig0_5(2606.549, 1842.9913);
const Point2d fig1_5(4691.5251, 1472.6383);
const Point2d fig0_6(2670.8824, 3619.915);
const Point2d fig1_6(2926.5142, 1252.146);
const Point2d fig0_7(3337.5948, 3087.3878);
const Point2d fig1_7(3219.4096, 1775.8519);
const Point2d fig0_8(5371.3442, 3125.2789);
const Point2d fig1_8(2545.8736, 3594.1373);

const Point2d fig0[8] = { fig0_1, fig0_2, fig0_3, fig0_4, fig0_5, fig0_6, fig0_7, fig0_8 };
const Point2d fig1[8] = { fig1_1, fig1_2, fig1_3, fig1_4, fig1_5, fig1_6, fig1_7, fig1_8 };

int main() {
	/* Part 2 - Calculate euler angles, translation vectors and matrix F */
	// Definitions 
	Mat F, E;
	vector<MatrixXd> RT;
	Matrix3d K_m, R;
	map<int, vector<Point2d>> points_map;
	string path = "G:/cpp/cv_2/Data/data.txt";
	vector<Point2d> all_pts1, all_pts2, pts1, pts2;
	Vector3d euler;

	K_m << 4705.5337, 0, 3944.07, 0, 4705.5337, 2612.675, 0, 0, 1;
	
	// No RANSAC 
	F = calF(fig0, fig1);						// Estimate matrix F
	verifyF(F);									// Test
	E = calE(F);

	// Using all points to verify the best_
	readPoints(path, points_map);
	for (const auto& entry : points_map) {
		const vector<Point2d>& points = entry.second;
		if (points.size() == 2) {
			all_pts1.push_back(points[0]);
			all_pts2.push_back(points[1]);
		}
	}

	for (int i = 0; i < 8; i++) {
		pts1.push_back(fig0[i]);
		pts2.push_back(fig1[i]);
	}
	// Using all points in the txt file 
	RT = calRT(E, all_pts1, all_pts2, K_m);
	// Using only 8*2 points 
	//RT = calRT(E, pts1, pts2, K_m);

	R = RT[0].leftCols(3);
	// Output R, t 
	if (!RT.empty()) {
		cout << "R = \n" << R << endl;
		cout << "t = \n" << RT[0].rightCols(1) << endl;
	}
	else {
		std::cout << "NO RT FOUND!" << endl;
	}
	// Verify R and t 
	//cout << "R^T * R = \n" << RT[0].leftCols(3).transpose() * RT[0].leftCols(3) << endl;
	//cout << "det(R) = " << RT[0].leftCols(3).determinant() << endl;
	//cout << "||t|| = " << RT[0].rightCols(1).norm() << endl;
	
	// Output euler angles and translation vetors
	euler = R.eulerAngles(2, 1, 0);
	cout << "Euler angles (ZYX: degree) : \n" << endl;
	cout << "Z = " << euler[0] * 180.0 / CV_PI << endl;
	cout << "Y = " << euler[1] * 180.0 / CV_PI << endl;
	cout << "X = " << euler[2] * 180.0 / CV_PI << endl;

	//cout << "--------OpenCV--------" << endl;
	//opencvTest(pts1, pts2);

	/* Part 2 - Calculate the length of ruler */
	vector<Vector2d> pointImg0 = {
		Vector2d(fig0_5.x, fig0_5.y),
		Vector2d(fig0_6.x, fig0_6.y),
		Vector2d(fig0_7.x, fig0_7.y),
		Vector2d(fig0_8.x, fig0_8.y)
	};
	vector<Vector2d> pointImg1 = {
		Vector2d(fig1_5.x, fig1_5.y),
		Vector2d(fig1_6.x, fig1_6.y),
		Vector2d(fig1_7.x, fig1_7.y),
		Vector2d(fig1_8.x, fig1_8.y)
	};
	calLength(RT, pointImg0, pointImg1);

	return 0;
}