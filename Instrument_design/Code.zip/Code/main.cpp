#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <iostream>
#include "med_filter.h"
#include "binarization.h"
#include "centre.h"

int main() {
	Mat image, image_filter, image_filter_Gray, image_otsu, image_otsu_filter, image_edge_canny, image_edge_sobel;
	double otsu_thresh_val;
	string path_ini;
	const int maxVal = 255;

	path_ini = "G:/cpp/Instrument_homework/ball_ini.png";
	image = imread(path_ini);			//��ȡ
	image_filter = med_filter(image);	//��ֵ�˲�
	cvtColor(image_filter, image_filter_Gray, COLOR_RGB2GRAY);	//ת��Ϊ�Ҷ�ͼ��
	int otsu_threshould = OTSU(image_filter_Gray);				//Otsu������ֵT
	cout << "Threshould\t" << otsu_threshould << endl;
	image_otsu = bin(image_filter_Gray, otsu_threshould);		//��ֵ��
	imwrite("G:/cpp/Instrument_homework/ball_bin.png", image_otsu);
	//imshow("11", image_otsu);

	GaussianBlur(image_otsu, image_otsu_filter, Size(5, 5), 2, 2);	//��˹�˲�
	Canny(image_otsu_filter, image_edge_canny, 50, 150);			//Canny��Ե��ȡ����ֵ�ɵ�
	//imshow("Canny Edges", image_edge);
	imwrite("G:/cpp/Instrument_homework/ball_edge_canny.png", image_edge_canny);
	//Sobel��Ե��ȡ
	Mat grad_x, grad_y;

	Sobel(image_otsu_filter, grad_x, CV_8U, 1, 0, 3, 1, 0, BORDER_DEFAULT);	//x����
	Sobel(image_otsu_filter, grad_y, CV_8U, 0, 1, 3, 1, 0, BORDER_DEFAULT);	//y����
	addWeighted(grad_x, 0.5, grad_y, 0.5, 0, image_edge_sobel);				//�ϲ�
	imwrite("G:/cpp/Instrument_homework/ball__edge_sobel.png", image_edge_canny);

	Point cc = centre(image, image_otsu);
	cout << "\nԲ��:\t(" << cc.x << ", " << cc.y << ")" << endl;

	//waitKey(0);
	return 0;
}