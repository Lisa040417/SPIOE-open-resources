#pragma once

#include <iostream>
#include <string>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

int OTSU(Mat srcImage);
Mat bin(Mat srcImage, int threshould);