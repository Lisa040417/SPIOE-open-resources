#pragma once
#include<iostream>
#include<opencv2/opencv.hpp>
#include <random>


using namespace cv;
using namespace std;

Mat med_filter(Mat image);
